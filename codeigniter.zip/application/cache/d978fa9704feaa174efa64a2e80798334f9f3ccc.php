<?php /* /var/www/codeigniter/application/views/templates/layouts/main.blade.php */ ?>
<!doctype html>
<html lang="en">
<?php $__env->startSection('head'); ?>
	<?php echo $__env->make('templates.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldSection(); ?>
<body>
<?php echo $__env->yieldContent('content'); ?>
<?php $__env->startSection('footer_scripts'); ?>
	<?php echo $__env->make('templates.includes.footer_scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldSection(); ?>
</body>
</html>