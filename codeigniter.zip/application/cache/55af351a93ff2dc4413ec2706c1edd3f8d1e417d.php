<?php /* /var/www/codeigniter/application/views/templates/index.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    hello world!
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>