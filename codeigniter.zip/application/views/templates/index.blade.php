@extends('templates.layouts.main')
@section('content')
    hello world!
@stop